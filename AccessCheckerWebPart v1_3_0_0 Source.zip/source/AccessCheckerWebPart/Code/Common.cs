/* 
 *  Created By: Tom Shirley
 *  Project URL: http://www.codeplex.com/accesschecker
 *  License: GNU GPL v2
 */
using System;
using System.Globalization;
using Microsoft.SharePoint;
using System.Reflection;
using Microsoft.SharePoint.Utilities;
using System.Web.UI.HtmlControls;
using System.Resources;
using System.Net;
using System.IO;
using System.Web;
    
namespace TomShirley.WebParts.AccessChecker
{
    public class Common
    {
        internal const bool NO = false;
        internal const bool YES = true;
        internal const string MATCHING_PERMISSIONS = "MatchingPermissions";
        internal const string DIFFERENT_PERMISSIONS = "DifferentPermissions";
        private static ResourceManager _ResourceManager;

        /// <summary>
        /// Displays a generic error to the user.
        /// </summary>
        /// <param name="errorMessage">The error message.</param>
        /// <param name="writer">The writer.</param>
        internal static void DisplayErrorToUser(string errorMessage, System.Web.UI.HtmlTextWriter writer)
        {
            HtmlGenericControl errorControl = new HtmlGenericControl("DIV");
            errorControl.Attributes.Add("style", "padding: 20px; margin: 20px; border-style: groove; background-color: #FFFFFF;");
            errorControl.InnerHtml = "<IMG src=\"/_layouts/images/error16by16.gif\" border=\"0\"/>" + errorMessage;
            errorControl.RenderControl(writer);
        }

        internal static ResourceManager ResourceManager
        {
            get
            {
                if (_ResourceManager == null)                
                    _ResourceManager = new ResourceManager("TomShirley.WebParts.AccessChecker.Localization", typeof(Common).Assembly);                
                
                return _ResourceManager;
            }
        }

        /// <summary>
        /// returns the current cultureinfo
        /// </summary>
        /// <returns></returns>
        internal static CultureInfo GetCultureInfo()
        {
            CultureInfo newCultureInfo;
            try
            {
                uint localeID = SPContext.Current.RegionalSettings.LocaleId;
                newCultureInfo = new CultureInfo((int)localeID);
            }
            catch
            {
                newCultureInfo = new CultureInfo(1033);
            }

            return newCultureInfo;
        }

        /// <summary>
        /// will return ex.ToString() or ex.Message depending on the comilation settings
        /// </summary>
        /// <param name="ex"></param>
        /// <returns></returns>
        internal static string GetErrorMessage(Exception ex)
        {
            if (ex != null)
            {
#if DEBUG
                return ex.ToString();
#else
                return ex.Message;
#endif
            }
            return string.Empty;
        }

        internal static SPBasePermissions RemoveCreateSSCSitePermissionFromMask(SPRoleDefinition roleDefinition)
        {
            return roleDefinition.BasePermissions & (SPBasePermissions.FullMask ^ SPBasePermissions.CreateSSCSite);            
        }

        /// <summary>
        /// Doeses the user have list permissions.
        /// </summary>
        /// <param name="login">The login.</param>
        /// <param name="list">The list.</param>
        /// <param name="web">The web.</param>
        /// <param name="permissionMask">The permission mask.</param>
        /// <returns></returns>
        internal static bool DoesUserHaveListPermissions(string login, SPList list, SPWeb web, SPBasePermissions permissionMask)
        {
            return ((GetUserListPermissions(login, list, web) & permissionMask) == permissionMask);  
        }

        /// <summary>
        /// Gets the user list permissions.
        /// This function was created by Gary Lapointe, please see http://stsadm.blogspot.com/2007/10/enumerate-effective-base-permissions.html
        /// Link active as of 2008-01-26.
        /// </summary>
        /// <param name="login">The login.</param>
        /// <param name="list">The list.</param>
        /// <param name="web">The web.</param>
        /// <returns></returns>
        internal static SPBasePermissions GetUserListPermissions(string login, SPList list, SPWeb web)
        {
            SPBasePermissions perms;

            PropertyInfo requestProp = web.GetType().GetProperty("Request",
                BindingFlags.NonPublic |
                BindingFlags.Instance |
                BindingFlags.InvokeMethod |
                BindingFlags.GetProperty);
            object request = requestProp.GetValue(web, null);

            MethodInfo getUserToken =
                request.GetType().GetMethod("GetUserToken",
                BindingFlags.NonPublic | BindingFlags.Public |
                BindingFlags.Instance | BindingFlags.InvokeMethod);

            try
            {
                SPUserToken token = new SPUserToken((byte[])getUserToken.Invoke(request, new object[] { web.Url, login }));

                MethodInfo getPermissions =
                    typeof(SPUtility).GetMethod("GetPermissions",
                        BindingFlags.NonPublic |
                        BindingFlags.Public |
                        BindingFlags.Instance |
                        BindingFlags.InvokeMethod |
                        BindingFlags.Static);

                perms = (SPBasePermissions)getPermissions.Invoke(null, new object[] { token, list });
            }
            catch (TargetInvocationException ex)
            {
                throw ex.InnerException;
            }
            return perms;
        }

        /// <summary>
        /// Replaces the invalid file name chars.
        /// </summary>
        /// <param name="filename">The filename.</param>
        /// <returns></returns>
        internal static string ReplaceInvalidFileNameChars(string filename)
        {
            // Get a list of invalid file characters.
            char[] invalidFileChars = Path.GetInvalidFileNameChars();

            foreach (char invalidFChar in invalidFileChars)
            {
                filename = filename.Replace(invalidFChar.ToString(), "");
            }
            return filename;
        }
 
    }
}
