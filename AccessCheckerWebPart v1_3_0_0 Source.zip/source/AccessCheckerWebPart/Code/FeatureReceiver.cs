/* 
 *  Created By: Tom Shirley
 *  Project URL: http://www.codeplex.com/accesschecker
 *  License: GNU GPL v2
 */
using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using System.Globalization;
using System.Resources;

namespace TomShirley.WebParts.AccessChecker
{
    public class FeatureReceiver : SPFeatureReceiver
    {
        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {            
            CultureInfo Cult = Common.GetCultureInfo();

            if (properties.Feature.Parent is SPWebService)
            {
                SPWebService webService = (SPWebService)properties.Feature.Parent;
                foreach (SPWebApplication webApp in webService.WebApplications)
                {
                    UpdateLayoutsSitemap uls = new UpdateLayoutsSitemap(webApp);
                    uls.AddSitemap(Common.ResourceManager.GetString("layouts_sitemap_Acess_Checker_xml", Cult));
                    uls.SubmitJob();
                }
            }
            else if (properties.Feature.Parent is SPWebApplication)
            {
                SPWebApplication oWebApp = (SPWebApplication)properties.Feature.Parent;
                UpdateLayoutsSitemap uls = new UpdateLayoutsSitemap(oWebApp);
                uls.AddSitemap(Common.ResourceManager.GetString("layouts_sitemap_Acess_Checker_xml", Cult));
                uls.SubmitJob();
            }
        }

        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {
            //throw new Exception("The method or operation is not implemented.");
        }

        public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        {
            //throw new Exception("The method or operation is not implemented.");
        }

        public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        {
            //throw new Exception("The method or operation is not implemented.");
        }
    }
}
