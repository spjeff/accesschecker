/* 
 *  Created By: Tom Shirley
 *  Project URL: http://www.codeplex.com/accesschecker
 *  License: GNU GPL v2
 *  Copyright (C) 2008 Tom Shirley
 * 
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 */
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Reflection;
using System.Resources;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.WebPartPages;
using System.Text;
using Microsoft.SharePoint.Utilities;
using arb.Generic.SharedLibrary.exceptionHandling;
using System.Diagnostics;
using System.Xml;
using System.Net;
using System.IO;
using System.Web;
using Microsoft.SharePoint.WebControls;

namespace TomShirley.WebParts.AccessChecker
{
    /// <summary>
    ///Quickly check what objects within a Sharepoint site hierarchy a user has access to. 
    ///
    ///The Access Checker Web Part is a .net 2.0 web part used within Windows Sharepoint Services v3 and/or Micorosoft Office Sharepoint Server 2007, 
    /// to display a tree view depicting permissions on securable objects for a user scoped to a Site hierarchy.
    ///
    ///More specifically, you can view graphically whether a user has a particular set of permissions on Sites and 
    /// Lists. Nodes within the tree view are colour coded to allow fast recognition of what Sites and Lists a user
    /// has access to, providing a site administrator the ability to answer the often raised question, 
    /// "do i have access to everything on this site?" 
    ///
    ///Without this web part there is no fast way for a site admin to determine if a user has access to all lists 
    /// and all sub-sites within a Site.
    ///
    ///Additional Features
    ///- View Permission Inheritance on Sites and Lists. Useful for site administrators to understand the 
    /// permissioning on their sites.
    ///
    ///Limitations
    ///- Folders/List Items are not displayed.
    /// </summary>
    public partial class AccessCheckerWebPart : WebPart
    {
        #region Properties
        private string _ErrorMessage = string.Empty;
        internal readonly CultureInfo _Cult;

        private SPWeb _CurrentWeb;
        private SPSite _CurrentSite;
        private TreeView _SharepointTreeView;
        private bool _AccessDeniedExceptionSetting;
        private Exception _Exception;

        // Contains user information
        private SPPrincipalInfo _PrincipalInfo;
        // Conatins the SPRoleDefinition that is set by the user. The _RoleDefinition
        // is used to determine if the user in _PrincipalInfo has the base permissions in _RoleDefinition
        // on a securable object.
        private SPRoleDefinition _RoleDefintion;
        private SPBasePermissions _BasePermissions;

        // Controls for selecting AD User/Group or Sharepoint Group and role definition within web part.
        private PeopleEditor _PeoplePicker;
        private string _LoginAccountName;
        private DropDownList _RoleNameList;
        private Button _GenerateTreeviewForUserButton;
        internal RadioButtonList _TreeNodeFilterRadioList;
        private Label _MessageArea;
        private bool _DownloadReport;
        private DateTime _TimeGenerated;
        private const string ACCESS_CHECKER_LAYOUTS_PATH = @"/_layouts/AccessChecker/CheckUserAccess.aspx";

        private const string valuePathDivTagStart = "<div class=\"ACWP-TreeNodeValuePath\" style=\"display:none\" >";
        private const string valuePathDivTagEnd = "</div>";

        private const string DEFAULT_SHOW_USER_OR_WEB_PERMISSONS_VALUE = "User";
        private string _ShowUserOrWebPermissions = DEFAULT_SHOW_USER_OR_WEB_PERMISSONS_VALUE;

        private enum enumTreeNodeFilterState : int
        {
            ShowAll = 0,
            HideMatchingPermissionNodes = 1,
            HideDifferentPermissionNodes = 2
        }

        public enum enumShowUserOrWebPermissions : int
        {
            Web = 0,
            User = 1
        }

        /// <summary>
        /// Gets or sets a property which indicates the type of object to report permissions against.
        /// </summary>
        /// <value>The report object.</value>
        [Browsable(false), Category("Configuration"),
        DefaultValue(DEFAULT_SHOW_USER_OR_WEB_PERMISSONS_VALUE),
         WebPartStorage(Storage.Personal),
         FriendlyName("Report Object"), 
         Description("Choose object to display permissions for.")]
        public string ShowUserOrWebPermissions
        {
            get
            {
                if (_ShowUserOrWebPermissions == null)
                    return DEFAULT_SHOW_USER_OR_WEB_PERMISSONS_VALUE;
                else
                    return _ShowUserOrWebPermissions;
            }

            set
            {
                _ShowUserOrWebPermissions = value;    
            }
        }

        private string _treeNodeFilter = enumTreeNodeFilterState.ShowAll.ToString();

        /// <summary>
        /// Gets or sets a value to specify whether nodes that match the permissions of the current web
        /// should not be rendered.
        /// </summary>
        /// <value>The hide nodes.</value>
        [Browsable(false), Category("Configuration"),
        WebPartStorage(Storage.Personal),
        FriendlyName("Filter nodes in tree view"),
        Description("Filter nodes in tree view")]
        public string TreeNodeFilter
        {
            get
            {
                return _treeNodeFilter;
            }
            set
            {
                _treeNodeFilter = value;
            }
        }

        private const bool AUTO_EXPAND_DEFAULT = Common.YES;
        private bool _autoExpand = AUTO_EXPAND_DEFAULT;
        /// <summary>
        /// Gets or sets the if nodes are to be auto expanded.
        /// </summary>
        /// <value>The auto expand.</value>
        [Browsable(false), Category("Configuration"),
        DefaultValue(AUTO_EXPAND_DEFAULT),
        WebPartStorage(Storage.Personal),
        FriendlyName("Auto Expand"),
        Description("Auto Expand Nodes.")]
        public bool AutoExpand
        {
            get
            {
                return _autoExpand;
            }

            set
            {
               _autoExpand = value;
            }
        }

        private const bool DISPLAY_SUBWEBS_DEFAULT = Common.YES;
        private bool _DisplaySubWebs = DISPLAY_SUBWEBS_DEFAULT;

        /// <summary>
        /// Gets or sets a value indicating whether subwebs should be displayed in the tree view.
        /// </summary>
        /// <value><c>true</c> if user requires subwebs to be displayed; otherwise, <c>false</c>.</value>
        [Browsable(false), Category("Configuration"),
       DefaultValue(DISPLAY_SUBWEBS_DEFAULT),
        WebPartStorage(Storage.Personal),
        FriendlyName("Display Sub Webs"),
       Description("")]
        public bool DisplaySubWebs
        {
            get
            {
                return _DisplaySubWebs;
            }

            set
            {
                 _DisplaySubWebs = value;
            }   
        }
        private const bool IGNORE_CREATESSCSITE_PERMISSION_DEFAULT = Common.YES;
        private bool _IgnoreCreateSSCSitePermission = IGNORE_CREATESSCSITE_PERMISSION_DEFAULT;

        /// <summary>
        /// 
        /// </summary>
        /// <value></value>
        [Browsable(false), Category("Configuration"),
        DefaultValue(IGNORE_CREATESSCSITE_PERMISSION_DEFAULT),
        WebPartStorage(Storage.Personal),
        FriendlyName("Ignore CreateSSCSite permission"),
        Description("")]
        public bool IgnoreCreateSSCSitePermission
        {
            get
            {
                return _IgnoreCreateSSCSitePermission;
            }

            set
            {
                _IgnoreCreateSSCSitePermission = value;
            }
        }
        #endregion

        #region Constructor
        /// <summary>
        /// Initializes a new instance of the <see cref="AccessCheckerWebPart"/> class.
        /// </summary>
        public AccessCheckerWebPart()
        {
            _Cult = Common.GetCultureInfo();
            _CurrentWeb = SPContext.Current.Web;
            _CurrentSite = _CurrentWeb.Site;
            _siteGuid = _CurrentSite.ID;
        }
        #endregion

        #region Build control functions

        /// <summary>
        /// Called by the ASP.NET page framework to notify server controls that use composition-based implementation to create any child controls they contain in preparation for posting back or rendering.
        /// </summary>
        protected override void CreateChildControls()
        {
            base.CreateChildControls();
            try
            {
                AddUserLoginNameEntryControls();
                _MessageArea = new Label();
                _MessageArea.EnableViewState = false;
                Controls.Add(_MessageArea);
                _SharepointTreeView = new TreeView();
                _SharepointTreeView.EnableViewState = true;
                _GenerateTreeviewForUserButton = new Button();                
                _GenerateTreeviewForUserButton.Text = Common.ResourceManager.GetString("Go", _Cult);
                _GenerateTreeviewForUserButton.CssClass = "ms-toolbar ACWP_CheckAccessButton";
                _GenerateTreeviewForUserButton.Click += new EventHandler(_GenerateTreeviewForUserButton_Click);               
                Controls.Add(_GenerateTreeviewForUserButton);
                _TreeNodeFilterRadioList = CreateTreeNodeFilterRadioList();
                Controls.Add(_TreeNodeFilterRadioList); // Add Filter Controls
                Controls.Add(_SharepointTreeView);
            }
            catch (Exception ex)
            {
                _ErrorMessage += string.Format("{0} CreateChildControls:\r\n{1}", Common.ResourceManager.GetString("Error_in", _Cult), Common.GetErrorMessage(ex));
            }
        }

        /// <summary>
        /// The event handler for the System.Web.UI.Control.PreRender event that occurs immediately before the Web Part is rendered to the Web Part Page it is contained on.
        /// </summary>
        /// <param name="e">A System.EventArgs that contains the event data.</param>
        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);
            try
            {
                EnsureChildControls();
                RegisterClientSideScripts();
                ConfigureControls();

                if (_SharepointTreeView != null && _SharepointTreeView.Nodes.Count > 0)
                    _SharepointTreeView.Nodes[0].Expand(); // Always have root node expanded
            }
            catch (Exception ex)
            {
                _ErrorMessage += string.Format("{0} OnPreRender:\r\n{1}", Common.ResourceManager.GetString("Error_in", _Cult), Common.GetErrorMessage(ex));
            }
        }

        /// <summary>
        /// Determines which tool parts are displayed in the tool pane of the Web-based Web Part design user interface, and the order in which they are displayed.
        /// </summary>
        /// <returns>
        /// An array of type <see cref="T:Microsoft.SharePoint.WebPartPages.ToolPart"></see> that determines which tool parts will be displayed in the tool pane. If a Web Part that implements one or more custom properties does not override the <see cref="M:Microsoft.SharePoint.WebPartPages.WebPart.GetToolParts"></see> method, the base class method will return an instance of the <see cref="T:Microsoft.SharePoint.WebPartPages.WebPartToolPart"></see> class and an instance of the <see cref="T:Microsoft.SharePoint.WebPartPages.CustomPropertyToolPart"></see> class. An instance of the <see cref="T:Microsoft.SharePoint.WebPartPages.WebPartToolPart"></see> class displays a tool part for working with the properties provided by the WebPart base class. An instance of the <see cref="T:Microsoft.SharePoint.WebPartPages.CustomPropertyToolPart"></see> class displays a built-in tool part for working custom Web Part properties, as long as the custom property is of one of the types supported by that tool part. The supported types are: String, Boolean, Integer, DateTime, or Enum.
        /// </returns>
        public override ToolPart[] GetToolParts()
        {
            ToolPart[] toolparts = new ToolPart[3];
            WebPartToolPart wptp = new WebPartToolPart();
            CustomPropertyToolPart custom = new CustomPropertyToolPart();
            toolparts[1] = wptp;
            toolparts[2] = custom;
            toolparts[0] = new CustomToolPart();

            return toolparts;
        }

        /// <summary>
        /// Build the tree view that displays the Sharepoint structure from the current context web.
        /// </summary>
        /// <returns></returns>
        private Control BuildTreeView()
        {
            // Create the nodes in the tree view.
            _SharepointTreeView.Nodes.Add(ExpandWeb(_CurrentSite.OpenWeb(_CurrentWeb.ID), 0, MAX_NODE_DEPTH, true));
            _TimeGenerated = DateTime.UtcNow;
            // The client side script to colour nodes needs to know the value of ShowUserOrWebPermissions. 
            // The script can obtain this attribute value from the tree view html element.
            _SharepointTreeView.Attributes.Add("ShowUserOrWebPermissions", this.ShowUserOrWebPermissions);
            _SharepointTreeView.CssClass = "ACWP-SharepointTreeView";
            _SharepointTreeView.NodeStyle.CssClass = "ACWP-SharepointTreeViewNodeStyle";
            _SharepointTreeView.HoverNodeStyle.CssClass = "ACWP-SharepointTreeViewHoverNodeStyle";

            // The ValuePath property needs to be displayed in the rendered html, so that the javascript which
            // colours nodes in the tree can decide whether a tree node should be flagged as green or red.
            // My own notes: The TreeView is not rebuilt if unrelated postbacks occur on the page or the user initiates
            // a page refresh. In these cases the AppendTreeNodeValuePathToText function isn't called which is
            // responsible for outputting the valuePath as a hidden div tag within the Text property of a TreeNode. 
            // However the viewstate handles loading this previously set value. see http://msdn2.microsoft.com/en-us/library/ms972976.aspx
            foreach (TreeNode node in _SharepointTreeView.Nodes)
            {
                AppendTreeNodeValuePathToText(node);
            }

            return _SharepointTreeView;
        }

        /// <summary>
        /// Adds the user login-name entry controls.
        /// </summary>
        private void AddUserLoginNameEntryControls()
        {
            _PeoplePicker = new PeopleEditor();
            _RoleNameList = new DropDownList();

            _RoleNameList.ToolTip = Common.ResourceManager.GetString("Role_Name_List_Tool_Tip", _Cult);

            _PeoplePicker.AutoPostBack = false;
            _PeoplePicker.ToolTip = Common.ResourceManager.GetString("People_Picker_Tool_Tip", _Cult);
            _PeoplePicker.PlaceButtonsUnderEntityEditor = true;
            _PeoplePicker.ID = "PeopleEditor";
            _PeoplePicker.AllowEmpty = false;
            _PeoplePicker.SelectionSet = "User,SecGroup";
            _PeoplePicker.MultiSelect = false;

            Controls.Add(_PeoplePicker);

            foreach (SPRoleDefinition role in GetRoleDefinitionsOfContextWeb())
            {
                ListItem item = new ListItem(role.Name, role.Id.ToString());
                _RoleNameList.Items.Add(item);
            }
            Controls.Add(_RoleNameList);
        }

        /// <summary>
        /// Configures the ButtonRadioList control used to filter nodes in the TreeView.
        /// </summary>
        internal void ConfigureTreeNodeFilterRadioList(RadioButtonList TreeNodeFilterRadioList)
        {
            ListItem tempItem;
            bool selectedItemSet = false;

            if (TreeNodeFilterRadioList.SelectedItem != null)
                return;

            tempItem = TreeNodeFilterRadioList.Items.FindByValue(enumTreeNodeFilterState.HideMatchingPermissionNodes.ToString());
            if (this.TreeNodeFilter == enumTreeNodeFilterState.HideMatchingPermissionNodes.ToString())
            {
                tempItem.Selected = true;
                selectedItemSet = true;
            }
            // Clear any previously set value. This function is called twice when a user modifies the TreeNodeFilter
            // value via the Web Part Pane method. The stack trace is:
            // ConfigureTreeNodeFilterRadioList->ApplyChanges->ConfigureTreeNodeFilterRadioList
            else
                tempItem.Selected = false;
            if (tempItem != null && this.ShowUserOrWebPermissions.Equals(enumShowUserOrWebPermissions.User.ToString()))
                tempItem.Text = Common.ResourceManager.GetString("User_Filter_Matching_Permission_Nodes", _Cult);
            else
                tempItem.Text = Common.ResourceManager.GetString("Web_Filter_Matching_Permission_Nodes", _Cult);
            tempItem = TreeNodeFilterRadioList.Items.FindByValue(enumTreeNodeFilterState.HideDifferentPermissionNodes.ToString());
            if (this.TreeNodeFilter == enumTreeNodeFilterState.HideDifferentPermissionNodes.ToString())
            {
                tempItem.Selected = true;
                selectedItemSet = true;
            }
            else
                tempItem.Selected = false;
            if (tempItem != null && this.ShowUserOrWebPermissions.Equals(enumShowUserOrWebPermissions.User.ToString()))
                    tempItem.Text = Common.ResourceManager.GetString("User_Filter_Different_Permission_Nodes", _Cult);
            else
                tempItem.Text = Common.ResourceManager.GetString("Web_Filter_Different_Permission_Nodes", _Cult);

            if (selectedItemSet != true)
            {
                tempItem = TreeNodeFilterRadioList.Items.FindByValue(enumTreeNodeFilterState.ShowAll.ToString());
                tempItem.Selected = true;
            }
        }

        /// <summary>
        /// Build a radio button list control used to hide nodes in the tree view.
        /// </summary>
        internal RadioButtonList CreateTreeNodeFilterRadioList()
        {
            RadioButtonList TreeNodeFilterRadioList = new RadioButtonList();
            TreeNodeFilterRadioList.Items.Add(new ListItem(Common.ResourceManager.GetString("Show_All_Nodes", _Cult), enumTreeNodeFilterState.ShowAll.ToString()));
            TreeNodeFilterRadioList.Items.Add(new ListItem("", enumTreeNodeFilterState.HideMatchingPermissionNodes.ToString()));
            TreeNodeFilterRadioList.Items.Add(new ListItem("", enumTreeNodeFilterState.HideDifferentPermissionNodes.ToString()));
            TreeNodeFilterRadioList.RepeatDirection = RepeatDirection.Vertical;

            return TreeNodeFilterRadioList;
        }

        /// <summary>
        /// Configures the controls for the web part.
        /// </summary>
        private void ConfigureControls()
        {
            bool propertiesAreValid = true;
            int roleID;

            // Always re-build tree view if there is no viewstate (no nodes), or the treeview is showing web inheritance
            // as there is no way to force a re-build for the user, whereas if we are showing user permissions
            // then the user can click Go to force a re-build.
            if (ShowUserOrWebPermissions.Equals(enumShowUserOrWebPermissions.Web.ToString()))
                DeleteAllNodesInTreeView();

            if (_SharepointTreeView.Nodes.Count == 0)
            {
                try
                {
                    // Stop Sharepoint from catching access denied exception, so this WP can handle them.
                    _AccessDeniedExceptionSetting = SPSecurity.CatchAccessDeniedException;
                    SPSecurity.CatchAccessDeniedException = false;
                    if (_CurrentWeb.DoesUserHavePermissions(SPBasePermissions.EnumeratePermissions))
                    {
                        ProcessQueryStringValues();
                        // If the user wants to view permissions for a loginname, then we need to
                        // resolve the User login name, and also resolve the role definition that the user's permissions is to be
                        // compared against.
                        if (this.ShowUserOrWebPermissions.Equals(enumShowUserOrWebPermissions.User.ToString()))
                        {
                            if (_RoleNameList.SelectedValue != null)
                            {
                                roleID = System.Convert.ToInt32(_RoleNameList.SelectedValue);
                                if (roleID > 0 && roleID <= Int32.MaxValue)
                                { 
                                    _RoleDefintion = _CurrentWeb.RoleDefinitions.GetById(roleID);
                                    // Remove the CreateSSCSite permission from the role that is to be used
                                    // to compare permissions against. The is done because:
                                    // If a user copies a permission set within the UI, the CreateSSCSite permission
                                    // isn't copied to the new permission group, moreover there is no option on the 
                                    // permission level page to select this permission mask. Therefore two seemingly identical 
                                    // permission sets (e.g. Read and Read_Copy) do not show identical results in
                                    // this web part (i.e. nodes don't have the same pass/fail colors).
                                    if (IgnoreCreateSSCSitePermission)
                                        _BasePermissions = Common.RemoveCreateSSCSitePermissionFromMask(_RoleDefintion);
                                    else
                                        _BasePermissions = _RoleDefintion.BasePermissions;
                                }
                            }

                            if (_PeoplePicker.ResolvedEntities.Count == 1)
                            {
                                try
                                {
                                    _LoginAccountName = GetAccountNameFromPeoplePicker();
                                    SetPrincipalInfo(_LoginAccountName);
                                }
                                catch (ArgumentException argEx)
                                {
                                    _MessageArea.Text = argEx.Message;
                                }
                            }

                            if (_PrincipalInfo == null || _RoleDefintion == null)
                                propertiesAreValid = false;
                        }
                        else
                        {
                            _GenerateTreeviewForUserButton.Text = Common.ResourceManager.GetString("Apply_Filter_Button", _Cult);
                        }

                        if (propertiesAreValid)
                        {
                            BuildTreeView();
                            // Expand All Nodes if user has set AutoExpand property to "Yes"
                            if (this.AutoExpand == Common.YES)
                                this._SharepointTreeView.ExpandAll();
                            else
                                this._SharepointTreeView.CollapseAll();
                        }
                        else
                            _SharepointTreeView = null;
                    }
                    else
                    {
                        _MessageArea.Text = Common.ResourceManager.GetString("Do_Not_Have_Permissions", _Cult);
                    }
                }
                finally
                {
                    SPSecurity.CatchAccessDeniedException = _AccessDeniedExceptionSetting;
                }
            }
            ConfigureTreeNodeFilterRadioList(this._TreeNodeFilterRadioList);
        }

        #endregion

        #region Render control functions

        /// <summary>
        /// Inherited from System.Web.UI.Control.
        /// </summary>
        /// <param name="writer">The HtmlTextWriter object that receives the server control content.</param>
        protected override void Render(System.Web.UI.HtmlTextWriter writer)
        {
            EnsureChildControls();

            try
            {
                if (String.IsNullOrEmpty(_ErrorMessage))
                {
                    if (_DownloadReport && _SharepointTreeView != null)
                    {
                        DownloadAccessCheckerReport(_SharepointTreeView, ShowUserOrWebPermissions, _PrincipalInfo, _RoleDefintion);
                    }
                    else
                    {
                        writer.Write("<table>");
                        writer.Write("<tr><td class=\"ACWP-MessageArea\">");
                        _MessageArea.RenderControl(writer);
                        writer.Write("</td></tr>");
                        writer.Write("</table>");

                        writer.Write("<table>");
                        writer.Write("<tr><td>");
                        RenderToolbar(writer);
                        RenderAllFields(writer);
                        writer.Write("</td></tr>");
                        writer.Write("</table>");

                        if (_SharepointTreeView != null && _SharepointTreeView.Nodes.Count > 0)
                        {                            
                            RenderNodeDescription(writer);
                            
                            writer.Write("<table>");
                            writer.Write("<tr><td>");
                            _SharepointTreeView.RenderControl(writer); // render the treeview
                            writer.Write("</td></tr>");
                            writer.Write("</table>");
                        }
                    }
                }
                else
                {
                    Common.DisplayErrorToUser(_ErrorMessage, writer);
                    SPSecurity.CodeToRunElevated elevatedLogError = new SPSecurity.CodeToRunElevated(ElevatedLogError);
                    SPSecurity.RunWithElevatedPrivileges(elevatedLogError);
                    //LogError(_ErrorMessage); // The current GenericExceptionHandler class logs to assembly dir. This is causing access denied errors. I am yet to determine where/if i should log to file. So for the meantime i am logging to event logs only
                }
            }
            catch (Exception ex)
            {
                Common.DisplayErrorToUser(Common.GetErrorMessage(ex), writer);
                _Exception = ex;
                SPSecurity.CodeToRunElevated elevatedLogError = new SPSecurity.CodeToRunElevated(ElevatedLogError);
                SPSecurity.RunWithElevatedPrivileges(elevatedLogError);
            }
        }

        /// <summary>
        /// Render a description of the tree node coloring to help users understand what the tree view displays.
        /// </summary>
        /// <param name="writer">The writer.</param>
        private void RenderNodeDescription(HtmlTextWriter writer)
        {
            writer.Write("<table class=\"ACWP_NodeDescriptionTable\">");
            writer.Write("<tr><td>");
            writer.Write(GetNodeFilterDescription());
            writer.Write("</td></tr>");
            writer.Write("</table>");
        }

        /// <summary>
        /// Renders the radio button list control used to filter nodes in the TreeView.
        /// </summary>
        /// <param name="writer">The writer.</param>
        private void RenderTreeNodeFilterRadioList(System.Web.UI.HtmlTextWriter writer)
        {
            writer.Write("<tr><td class=\"ms-formlabel\">");
            writer.Write(Common.ResourceManager.GetString("Filter_Options_Title", _Cult));                        
            writer.Write("</td>");
            writer.Write("<td class=\"ms-formbody\">");
            this._TreeNodeFilterRadioList.RenderControl(writer);
            writer.Write("</td>");
            writer.Write("</tr>");
        }

        /// <summary>
        /// Render the user login and access level controls.
        /// </summary>
        /// <param name="writer">The writer.</param>
        private void RenderLoginAndAccessControls(System.Web.UI.HtmlTextWriter writer)
        {           
            writer.Write("<tr><td class=\"ms-formlabel\">");
            writer.Write(Common.ResourceManager.GetString("User_Login_Name_Label", _Cult));
            writer.Write("</td>");
            writer.Write("<td class=\"ms-formbody\">");
            _PeoplePicker.RenderControl(writer);
            writer.Write("</td></tr>");
            writer.Write("<tr><td class=\"ms-formlabel\">");
            writer.Write(Common.ResourceManager.GetString("User_Role_Name_Label", _Cult));
            writer.Write("</td>");
            writer.Write("<td class=\"ms-formbody\">");
            _RoleNameList.RenderControl(writer);
            writer.Write("</td></tr>");                        
        }

        /// <summary>
        /// Render all fields that the user needs to fill in to display the tree view.
        /// </summary>
        /// <param name="writer">The writer.</param>
        private void RenderAllFields(System.Web.UI.HtmlTextWriter writer)
        {
            writer.Write("<table class=\"ms-formtable ACWP_formtable\">");
            if (this.ShowUserOrWebPermissions.Equals(enumShowUserOrWebPermissions.User.ToString()))
            {
                RenderLoginAndAccessControls(writer);
            }
            RenderTreeNodeFilterRadioList(writer);
            writer.Write("</table>");
        }

        /// <summary>
        /// Render the toolbar that contains all actions available to the user.
        /// </summary>
        /// <param name="writer">The writer.</param>
        private void RenderToolbar(System.Web.UI.HtmlTextWriter writer)
        {
            writer.Write("<table class=\"ms-toolbar\" width=\"100%\" cellpadding=\"2\">");
            writer.Write("<tr>");
            if (_SharepointTreeView != null && _SharepointTreeView.Nodes.Count > 0)
            {
                //writer.Write("<td class=\"ms-separator\">|</td>");
                writer.Write("</td>");
                // Render Download Report link
                writer.Write("<td class=\"ms-toolbar\">");
                string url = this._CurrentWeb.Url + ACCESS_CHECKER_LAYOUTS_PATH +
                                 "?Mode=" + HttpUtility.UrlEncode(_ShowUserOrWebPermissions) +
                                 "&Login=" + HttpUtility.UrlEncode(_LoginAccountName == null ? "" : _LoginAccountName.Replace(@"\", @"\\")) +
                                 "&Access=" + HttpUtility.UrlEncode(_RoleNameList.SelectedItem.Text) +
                                 "&DownloadReport=true";
                writer.Write("<a href=\"javascript:void window.open('" + url + "')\">" + Common.ResourceManager.GetString("Download_Report", _Cult) + "</a>");
                writer.Write("</td>");
            }
            writer.Write("<td class=\"ms-toolbar\" align=\"right\">");
            _GenerateTreeviewForUserButton.RenderControl(writer);
            writer.Write("</td>");
            writer.Write("</tr>");
            writer.Write("</table>");
        }

        #endregion

        #region Misc functions
      
        /// <summary>
        /// Processes the query string values. This function is used primarily to populate input values via query strings
        /// so as to be able to download a report of the permissions via a link.
        /// </summary>
        private void ProcessQueryStringValues()
        {
            bool allQSValuesValidForUserMode = true;
            string value;

            if (this.Page.Request.QueryString.Count > 0)
            {
                try
                {
                    if (this.Page.Request.QueryString["Mode"] != null)
                    {
                        value = HttpUtility.UrlDecode(this.Page.Request.QueryString["Mode"]);
                        if (Enum.IsDefined(typeof(enumShowUserOrWebPermissions), value))
                        {
                            ShowUserOrWebPermissions = Enum.Parse(typeof(enumShowUserOrWebPermissions), value, true).ToString();
                        }
                        else
                            throw new ApplicationException(Common.ResourceManager.GetString("Query_String_Invalid", _Cult));
                    }
                    else
                        allQSValuesValidForUserMode = false;

                    if (this.Page.Request.QueryString["Login"] != null)
                    {
                        value = HttpUtility.UrlDecode(this.Page.Request.QueryString["Login"]);

                        // Need to reference .CommaSeparatedAccounts property before calling .Entities because 
                        // the collection seems to only get populated after that property is referenced.
                        string temp = _PeoplePicker.CommaSeparatedAccounts;
                        PickerEntity pickerEntity = new PickerEntity();
                        pickerEntity.Key = value;

                        try
                        {
                            _PeoplePicker.Entities.Add(pickerEntity);
                            _PeoplePicker.UpdateEntities(_PeoplePicker.Entities);
                        }
                        catch (Exception e)
                        {
                            allQSValuesValidForUserMode = false;
                            // If an error occurs we need to clear the entities collection otherwise
                            // the people picker will try and validate them again and fail... again.
                            _PeoplePicker.Entities.Clear();                             
                        }
                    }
                    else
                        allQSValuesValidForUserMode = false;

                    if (this.Page.Request.QueryString["Access"] != null)
                    {
                        value = HttpUtility.UrlDecode(this.Page.Request.QueryString["Access"]);
                        ListItem item = _RoleNameList.Items.FindByText(value);
                        if (item != null)
                        {
                            item.Selected = true;
                        }
                        else
                            throw new ApplicationException(Common.ResourceManager.GetString("Query_String_Invalid", _Cult));
                    }
                    else
                        allQSValuesValidForUserMode = false;

                    if (this.Page.Request.QueryString["DownloadReport"] != null)
                    {
                        value = HttpUtility.UrlDecode(this.Page.Request.QueryString["DownloadReport"]);
                        if (value.ToLower().CompareTo("true") == 0)
                        {
                            // If all the required query string values have been specified and are valid, then flag that
                            // this web part is to respond to the user with an xml report file.
                            if ((ShowUserOrWebPermissions.Equals(enumShowUserOrWebPermissions.User.ToString()) && allQSValuesValidForUserMode) ||
                                ShowUserOrWebPermissions.Equals(enumShowUserOrWebPermissions.Web.ToString()))                            
                                this._DownloadReport = true;                            
                            else
                                throw new ApplicationException(Common.ResourceManager.GetString("Query_String_Invalid", _Cult));
                        }
                    }
                }
                catch (ApplicationException appEx)
                {
                    _MessageArea.Text = appEx.Message;
                }
                catch (Exception e)
                {
                    throw new ApplicationException(Common.ResourceManager.GetString("Query_String_Processing_Failed", _Cult));
                }
            }
        }

        /// <summary>
        /// Gets the account name from people picker.
        /// </summary>
        /// <returns></returns>
        private string GetAccountNameFromPeoplePicker()
        {
            string accountName = String.Empty;

            if (_PeoplePicker.ResolvedEntities.Count != 1)
            {
                throw new ApplicationException(Common.ResourceManager.GetString("Single_Account_Not_Selected", _Cult));
            }

            PickerEntity pickerEntity = (PickerEntity)_PeoplePicker.ResolvedEntities[0];
            accountName = pickerEntity.Key;
            //Common.GetUserListPermissions(accountName, this._CurrentWeb.Lists["Announcements"], this._CurrentWeb);
            return accountName;
        }

        /// <summary>
        /// Gets the node filter description to display to the user.
        /// </summary>
        /// <returns></returns>
        private string GetNodeFilterDescription()
        {
            String description = String.Empty;
            bool HideMatchingNodes = false;
            bool HideDifferentNodes = false;

            if (this._TreeNodeFilterRadioList.SelectedValue == enumTreeNodeFilterState.HideMatchingPermissionNodes.ToString())
                HideMatchingNodes = true;
            if (this._TreeNodeFilterRadioList.SelectedValue == enumTreeNodeFilterState.HideDifferentPermissionNodes.ToString())
                HideDifferentNodes = true;

            if (HideMatchingNodes)
            {
                if (this.ShowUserOrWebPermissions.Equals(enumShowUserOrWebPermissions.Web.ToString()))
                    description = String.Format(Common.ResourceManager.GetString("Web_Filter_Matching_Permission_Nodes_Long_Description", _Cult));
                else
                {
                    if (_PrincipalInfo != null && _RoleDefintion != null)
                        description = String.Format(Common.ResourceManager.GetString("User_Filter_Matching_Permission_Nodes_Long_Description", _Cult), this._PrincipalInfo.DisplayName, this._RoleDefintion.Name);
                }
            }
            else if (HideDifferentNodes)
            {
                if (this.ShowUserOrWebPermissions.Equals(enumShowUserOrWebPermissions.Web.ToString()))
                    description = String.Format(Common.ResourceManager.GetString("Web_Filter_Different_Permission_Nodes_Long_Description", _Cult));
                else
                {
                    if (_PrincipalInfo != null && _RoleDefintion != null)
                        description = String.Format(Common.ResourceManager.GetString("User_Filter_Different_Permission_Nodes_Long_Description", _Cult), this._PrincipalInfo.DisplayName, this._RoleDefintion.Name);
                }
            }
            else
            {
                if (this.ShowUserOrWebPermissions.Equals(enumShowUserOrWebPermissions.Web.ToString()))
                    description = String.Format(Common.ResourceManager.GetString("Web_Show_All_Nodes_Long_Description", _Cult));
                else
                {
                    if (_PrincipalInfo != null && _RoleDefintion != null)
                        description = String.Format(Common.ResourceManager.GetString("User_Show_All_Nodes_Long_Description", _Cult), this._PrincipalInfo.DisplayName, this._RoleDefintion.Name);
                }
            }

            return description;
        }

        /// <summary>
        /// Deletes all nodes in _SharepointTreeView.
        /// </summary>
        internal void DeleteAllNodesInTreeView()
        {
            _SharepointTreeView.Nodes.Clear();
        }


        /// <summary>
        /// Sets the principal info give a login name.
        /// </summary>
        /// <param name="loginName">Name of the login.</param>
        internal void SetPrincipalInfo(string loginName)
        {
            if (loginName.Contains("\\"))
            {
                _PrincipalInfo = SPUtility.ResolveWindowsPrincipal(_CurrentSite.WebApplication, loginName, SPPrincipalType.All, false);
                if (_PrincipalInfo == null)
                    throw new ArgumentException(Common.ResourceManager.GetString("Login_Name_Does_Not_Exist", _Cult));
            }
            else
                throw new ArgumentException(Common.ResourceManager.GetString("Login_Format_Incorrect", _Cult));            
        }

        /// <summary>
        /// Gets the role definitions of context web.
        /// </summary>
        /// <returns></returns>
        internal SPRoleDefinitionCollection GetRoleDefinitionsOfContextWeb()
        {
            return _CurrentWeb.RoleDefinitions;
        }

        private string GetClassResourceFilePath()
        {
            // Returns the physical path of the class resource folder
            int iPos = 0;
            string sPrecedingPath = "";
            string sResourcePath = this.ClassResourcePath;

            // Get the position of the wpresources text
            iPos = sResourcePath.ToLower().IndexOf("wpresources");

            // Get the part of the string preceeding the wpresources text
            sPrecedingPath = sResourcePath.Substring(1, iPos);

            // Get the position of the preceding slash to get the start
            // of the string to return

            // This allows both the GAC and the /bin wpresource
            // locations - ie /_wpresources or /wpresources

            iPos = sPrecedingPath.LastIndexOf("/") + 1;

            if (iPos > 1)
            {
                sResourcePath =
                    sResourcePath.Substring(iPos,
                    sResourcePath.Length - iPos);
            }

            return this.Context.Server.MapPath(sResourcePath);
        }


        private void ElevatedLogError()
        {
            if (_Exception != null)
                LogError(_Exception.Message);
            else
                LogError(_ErrorMessage);
        }

        private void LogError(string message)
        {
            GenericExceptionHandler.LogPath = GetClassResourceFilePath();
            GenericExceptionHandler.StartLogging();
            GenericExceptionHandler.TraceLevel = TraceLevel.Verbose;
            GenericExceptionHandler.EventSourceName = "AccessCheckerWebPart";
            GenericExceptionHandler.WriteLine(TraceLevel.Error, message);
            GenericExceptionHandler.StopLogging();
        }

        /// <summary>
        /// Registers client side scripts used for style and formatting of the TreeView.
        /// </summary>
        private void RegisterClientSideScripts()
        {
            String scriptName = "ACWP_ColourCodingScript_" + _SharepointTreeView.ClientID;
            String EmbeddedResourceFullName;
            Type cstype = this.GetType();
            bool HideMatchingNodes = false;
            bool HideDifferentNodes = false;

            // Get a ClientScriptManager reference from the Page class.
            ClientScriptManager scriptManager = Page.ClientScript;

            // Register javascript block which colour codes nodes in the TreeView.
            if (!scriptManager.IsClientScriptBlockRegistered(cstype, scriptName))
            {
                if (this._TreeNodeFilterRadioList.SelectedValue == enumTreeNodeFilterState.HideMatchingPermissionNodes.ToString())
                    HideMatchingNodes = true;
                if (this._TreeNodeFilterRadioList.SelectedValue == enumTreeNodeFilterState.HideDifferentPermissionNodes.ToString())
                    HideDifferentNodes = true;

                scriptManager.RegisterClientScriptBlock(cstype, scriptName, ScriptFactory.GetColourCodingScript(_SharepointTreeView.ClientID, this.ShowUserOrWebPermissions, HideMatchingNodes, HideDifferentNodes, Common.ResourceManager, _Cult));
            }

            // Register the style sheet on the current page.
            scriptName = "ACWP_StyleSheet";
            EmbeddedResourceFullName = "TomShirley.WebParts.AccessChecker.AccessCheckerStyle.css";
            if (!scriptManager.IsClientScriptBlockRegistered(cstype, scriptName))
            {
                StreamHelper.EnsureWebResourceValid(EmbeddedResourceFullName, this.GetType().Assembly, true);
                string jsURL = scriptManager.GetWebResourceUrl(cstype, EmbeddedResourceFullName);

                StringBuilder cstext = new StringBuilder();
                cstext.Append("<link href=\"" + jsURL + "\"");
                cstext.Append(" rel=\"stylesheet\"");
                cstext.Append(" type=\"text/css\" />");
                scriptManager.RegisterClientScriptBlock(cstype, scriptName, cstext.ToString(), false);
            }
        }

        /// <summary>
        /// Appends a TreeNode's valuePath property to its Text property for all nodes within the specified
        /// root node.
        /// </summary>
        /// <param name="rootNode">The root node.</param>
        private void AppendTreeNodeValuePathToText(TreeNode rootNode)
        {
            foreach (TreeNode childNode in rootNode.ChildNodes)
            {
                AppendTreeNodeValuePathToText(childNode);
            }
            rootNode.Text += valuePathDivTagStart + rootNode.ValuePath + valuePathDivTagEnd;
        }

        /// <summary>
        /// Removes a TreeNode's valuePath property from its Text property for all nodes within the specified
        /// root node.
        /// </summary>
        /// <param name="rootNode">The root node.</param>
        private void RemoveTreeNodeValuePathFromText(TreeNode rootNode)
        {
            foreach (TreeNode childNode in rootNode.ChildNodes)
            {
                RemoveTreeNodeValuePathFromText(childNode);
            }
            rootNode.Text = rootNode.Text.Replace(valuePathDivTagStart + rootNode.ValuePath + valuePathDivTagEnd, "");
        }

        #endregion

        #region Event Handlers
        /// <summary>
        /// Handles the Click event of the _GenerateTreeviewForUserButton control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void _GenerateTreeviewForUserButton_Click(object sender, EventArgs e)
        {
            try
            {
                DeleteAllNodesInTreeView(); // Clear nodes so that the treeview gets re-populated on the pre-render call               
            }
            catch (Exception ex)
            {
                _ErrorMessage += string.Format("{0} _GenerateUserReportButton_Click:\r\n{1}", Common.ResourceManager.GetString("Error_in", _Cult), Common.GetErrorMessage(ex));
            }
        }
        #endregion
    }
}
