/* 
 *  Created By: Tom Shirley
 *  Project URL: http://www.codeplex.com/accesschecker
 *  License: GNU GPL v2
 */
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.SharePoint.Utilities;
using System.Globalization;
using System.Resources;

namespace TomShirley.WebParts.AccessChecker
{
    static class ScriptFactory
    {  
        /// <summary>
        /// Get a javascript block used to colour code tree nodes for a specified TreeView.
        /// </summary>
        /// <param name="treeViewID">The TreeView clientID.</param>
        /// <returns></returns>
        internal static string GetColourCodingScript(string treeViewID, string userOrWebPermissions, bool hideMatchingNodes, bool hideNonMatchingNodes,
                                                     ResourceManager resourceManager, CultureInfo cult)
        {
            StringBuilder sb = new StringBuilder();

            sb.Append(@"
<script type=""text/javascript"">
_spBodyOnLoadFunctionNames.push(""ACWP_ApplyColouringToTreeNodes_TREEVIEWID"");
");
            if (hideMatchingNodes)
                sb.Append(@"var hideMatchingNodes = true;");
            else
                sb.Append(@"var hideMatchingNodes = false;");
            if (hideNonMatchingNodes)
                sb.Append(@"var hideNonMatchingNodes = true;");
            else
                sb.Append(@"var hideNonMatchingNodes = false;");

            // Create variables to hold alt text for images
            sb.Append("var greenAltText = \"" + resourceManager.GetString(userOrWebPermissions + "_greenAltText", cult) + "\";");
            sb.Append("var greenRedAltText = \"" + resourceManager.GetString(userOrWebPermissions + "_greenRedAltText", cult) + "\";");
            sb.Append("var redAltText = \"" + resourceManager.GetString(userOrWebPermissions + "_redAltText", cult) + "\";");
            sb.Append("var redGreenAltText = \"" + resourceManager.GetString(userOrWebPermissions + "_redGreenAltText", cult) + "\";");

            sb.Append(@"
function ACWP_InsertTextualInfo_TREEVIEWID(divElem, trNode, permissionsString, userOrWebPermissions)
{
    var s = """";

    if (permissionsString.match(""DIFFERENT_PERMISSIONS""))
    {
        // Colour link text
        divElem.parentNode.className += "" ACWP-DifferentPermissionsText"";
        if (userOrWebPermissions == ""User"")
        {
            s += ""<img src=\""/_layouts/images/AccessChecker/red.PNG\"" alt=\"""" + redAltText + ""\"" />"";
        }
    }
    else if (permissionsString.match(""MATCHING_PERMISSIONS""))
    {
        // Colour link text. Parent node is the <a> tag containing the link text
        divElem.parentNode.className += "" ACWP-MatchingPermissionsText"";
        if (userOrWebPermissions == ""User"")
        {
            s += ""<img src=\""/_layouts/images/AccessChecker/green.PNG\"" alt=\"""" + greenAltText + ""\"" />"";
        }
    }
    
    var newTD = document.createElement('td');
    trNode.insertBefore(newTD, trNode.firstChild);
    newTD.innerHTML = s;
    newTD.setAttribute('height', '100%');
    newTD.setAttribute('style', 'vertical-align:middle');
}
");

sb.Append(@"
function ACWP_ApplyColouringToTreeNodes_TREEVIEWID()
{	        
    var treeView = document.getElementById(""TREEVIEWID"");
    
    <!-- Check if the tree view control exists before attempting to colour code nodes -->
    if (treeView != null)
    {
        var divElems = treeView.getElementsByTagName(""div"");
        for (i=0; i<divElems.length; i++)
	    {	  
	        if (divElems[i].className == ""ACWP-TreeNodeValuePath"")
		    {   
                    var valuePath;

                    if (document.all){
                       valuePath = divElems[i].innerText.split(""|"");  
                    }
                    else {
                       valuePath = divElems[i].textContent.split(""|"");     
                    }
		   
                    ACWP_InsertTextualInfo_TREEVIEWID(divElems[i], divElems[i].parentNode.parentNode.parentNode, valuePath[valuePath.length-1], treeView.ShowUserOrWebPermissions);   				    			    				              
		    }
	    }
    }
}
</script>
");
            sb.Replace("TREEVIEWID", treeViewID);
            sb.Replace("DIFFERENT_PERMISSIONS", Common.DIFFERENT_PERMISSIONS);
            sb.Replace("MATCHING_PERMISSIONS", Common.MATCHING_PERMISSIONS);
            return sb.ToString();
        }
    }
}
