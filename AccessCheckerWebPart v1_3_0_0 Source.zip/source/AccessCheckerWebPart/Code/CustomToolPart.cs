/* 
 *  Created By: Tom Shirley
 *  Project URL: http://www.codeplex.com/accesschecker
 *  License: GNU GPL v2
 */
using System;
using System.Globalization;
using System.Resources;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.WebPartPages;
using System.Reflection;

namespace TomShirley.WebParts.AccessChecker
{
    /// <summary>
    /// Displays controls used to modify the AccessCheckerWebPart's properties.
    /// </summary>
    public class CustomToolPart : ToolPart
    {
        private string _ErrorMessage = string.Empty;
        private readonly CultureInfo _Cult;
        private AccessCheckerWebPart _parentWebPart;

        private DropDownList _ShowUserOrWebPermissionsList;
        private DropDownList _autoExpandList;
        private RadioButtonList _TreeNodeFilterRadioList;
        private DropDownList _DisplaySubWebsList;
        private DropDownList _IgnoreCreateSSCSitePermissionList;

        private void CustomToolPart_Init(object sender, EventArgs e)
        {
        }

        public CustomToolPart()
        {
            // Set default properties
            Title = "Access Checker";
            Init += CustomToolPart_Init;

            _ShowUserOrWebPermissionsList = new DropDownList();
            _autoExpandList = new DropDownList();
            _DisplaySubWebsList = new DropDownList();
            _IgnoreCreateSSCSitePermissionList = new DropDownList();
            _Cult = Common.GetCultureInfo();
        }

        ///	<summary>
        ///	Called by the tool pane to apply property changes to
        /// the selected Web Part.
        ///	</summary>
        public override void ApplyChanges()
        {
            bool parseResult;
            int intResult;
            try
            {
                bool childStateInvalid = false;

                // Establish a reference to the Web Part.
                _parentWebPart = (AccessCheckerWebPart)ParentToolPane.SelectedWebPart;

                if (!_parentWebPart.ShowUserOrWebPermissions.Equals(_ShowUserOrWebPermissionsList.SelectedValue))
                {
                    _parentWebPart.ShowUserOrWebPermissions = _ShowUserOrWebPermissionsList.SelectedValue;
                    childStateInvalid = true;
                }

                if (_parentWebPart.AutoExpand != (parseResult = System.Convert.ToBoolean(this._autoExpandList.SelectedValue)))
                {
                    _parentWebPart.AutoExpand = parseResult; childStateInvalid = true;
                }
                if (_parentWebPart.DisplaySubWebs != (parseResult = System.Convert.ToBoolean(this._DisplaySubWebsList.SelectedValue)))
                {
                    _parentWebPart.DisplaySubWebs = parseResult; childStateInvalid = true;
                }
                if (_parentWebPart.IgnoreCreateSSCSitePermission != (parseResult = System.Convert.ToBoolean(this._IgnoreCreateSSCSitePermissionList.SelectedValue)))
                {
                    _parentWebPart.IgnoreCreateSSCSitePermission = parseResult; childStateInvalid = true;
                }
                if (_parentWebPart.TreeNodeFilter != _TreeNodeFilterRadioList.SelectedValue)
                {
                    _parentWebPart.TreeNodeFilter = _TreeNodeFilterRadioList.SelectedValue; childStateInvalid = true;
                    // Sync changes to the RadioList control on the ToolPart pane with the 
                    // RadioList control displayed in the Web Part.
                    _parentWebPart._TreeNodeFilterRadioList.SelectedItem.Selected = false;
                    _parentWebPart._TreeNodeFilterRadioList.SelectedIndex = _TreeNodeFilterRadioList.SelectedIndex;
                }

                if (childStateInvalid)
                    _parentWebPart.DeleteAllNodesInTreeView();
            }
            catch (Exception ex)
            {
                _ErrorMessage += string.Format("{0} ApplyChanges:\r\n{1}", Common.ResourceManager.GetString("Error_in", _Cult), Common.GetErrorMessage(ex));
            }
        }

        /// <summary>
        ///	If the ApplyChanges method succeeds, this method is
        /// called by the tool pane to refresh the specified
        /// property values in the toolpart user interface.
        /// </summary>
        public override void SyncChanges()
        {
            // sync with the new property changes here
        }

        /// <summary>
        ///	Called by the tool pane if the user discards changes
        /// to the selected Web Part.
        /// </summary>
        public override void CancelChanges()
        {
        }

        /// <summary>
        /// Render this Tool part to the output parameter
        /// specified.
        /// </summary>
        /// <param name="writer">
        /// The HTML writer to write out to
        /// </param>
        protected override void RenderToolPart(HtmlTextWriter writer)
        {
            EnsureChildControls();

            try
            {

                if (!String.IsNullOrEmpty(_ErrorMessage))
                {
                    //DisplayErrorToUser(Common.ResourceManager.GetString("Generic_Error_Message", _Cult), writer);
                    //GenericExceptionHandler.WriteLine(TraceLevel.Error, _ErrorMessage);
                    Common.DisplayErrorToUser(Common.ResourceManager.GetString("Generic_Error_Message", _Cult), writer);                
                }

                writer.Write("<table>");
                writer.Write("<tr><td>");
                writer.Write(Common.ResourceManager.GetString("Report_Object", _Cult) + ":");
                writer.Write("</td></tr>");
                writer.Write("<tr><td padding-left=\"5px\">");
                _ShowUserOrWebPermissionsList.RenderControl(writer);
                writer.Write("</td></tr>");
                writer.Write("<tr><td>");
                writer.Write(Common.ResourceManager.GetString("Auto_Expand_Nodes", _Cult) + ":");
                writer.Write("</td></tr>");
                writer.Write("<tr><td padding-left=\"5px\">");
                this._autoExpandList.RenderControl(writer);
                writer.Write("</td></tr>");

                writer.Write("<tr><td>");
                writer.Write(Common.ResourceManager.GetString("Filter_Node_Option", _Cult) + ":");
                writer.Write("</td></tr>");
                writer.Write("<tr><td padding-left=\"5px\">");
                this._TreeNodeFilterRadioList.RenderControl(writer);
                writer.Write("</td></tr>");

                writer.Write("<tr><td>");
                writer.Write(Common.ResourceManager.GetString("Display_SubWebs", _Cult) + ":");
                writer.Write("</td></tr>");
                writer.Write("<tr><td padding-left=\"5px\">");
                this._DisplaySubWebsList.RenderControl(writer);
                writer.Write("</td></tr>");

                writer.Write("<tr><td>");
                writer.Write(Common.ResourceManager.GetString("Ignore_CreateSSCSite_Permission", _Cult) + ":");
                writer.Write("</td></tr>");
                writer.Write("<tr><td padding-left=\"5px\">");
                this._IgnoreCreateSSCSitePermissionList.RenderControl(writer);
                writer.Write("</td></tr>");
                writer.Write("</table>");   
            }
            catch (Exception ex)
            {
                Common.DisplayErrorToUser(ex.Message, writer);
                //DisplayErrorToUser(Common.ResourceManager.GetString("Generic_Error_Message", _Cult), writer);
                //GenericExceptionHandler.WriteLine(TraceLevel.Error, ex.ToString());
            }
        }

        protected override void CreateChildControls()
        {
            try
            {
                base.CreateChildControls();

                // Establish a reference to the Web Part.
                _parentWebPart = (AccessCheckerWebPart)ParentToolPane.SelectedWebPart;

                ConfigureShowUserOrWebPermissionsList();
                Controls.Add(_ShowUserOrWebPermissionsList);

                AddYesNoDropDownList(_parentWebPart.AutoExpand, this._autoExpandList);
                _TreeNodeFilterRadioList = _parentWebPart.CreateTreeNodeFilterRadioList();
                Controls.Add(_TreeNodeFilterRadioList);
                _parentWebPart.ConfigureTreeNodeFilterRadioList(_TreeNodeFilterRadioList);
                AddYesNoDropDownList(_parentWebPart.DisplaySubWebs, this._DisplaySubWebsList);
                AddYesNoDropDownList(_parentWebPart.IgnoreCreateSSCSitePermission, this._IgnoreCreateSSCSitePermissionList);
            }
            catch (Exception ex)
            {
                _ErrorMessage += string.Format("{0} CreateChildControls:\r\n{1}", Common.ResourceManager.GetString("Error_in", _Cult), Common.GetErrorMessage(ex));
            }
        }

        private void ConfigureShowUserOrWebPermissionsList()
        {
            ListItem listItem;
            listItem = new ListItem(Common.ResourceManager.GetString("User", _Cult),AccessCheckerWebPart.enumShowUserOrWebPermissions.User.ToString());

            // Set the current list item as the selected item if the saved
            // format value matches the current list items text value
            if (_parentWebPart.ShowUserOrWebPermissions.CompareTo(listItem.Text) == 0)
                listItem.Selected = true;
            _ShowUserOrWebPermissionsList.Items.Add(listItem);
            listItem = new ListItem(Common.ResourceManager.GetString("Web", _Cult), AccessCheckerWebPart.enumShowUserOrWebPermissions.Web.ToString());
            if (_parentWebPart.ShowUserOrWebPermissions.CompareTo(listItem.Text) == 0)
                listItem.Selected = true;
            _ShowUserOrWebPermissionsList.Items.Add(listItem);            
        }

        private void AddYesNoDropDownList(bool propertyValue, DropDownList list)
        {
            AddListItem(propertyValue, Common.ResourceManager.GetString("No", _Cult), Common.NO, list);
            AddListItem(propertyValue, Common.ResourceManager.GetString("Yes", _Cult), Common.YES, list);
            Controls.Add(list);
        }

        private void AddListItem(bool propertyValue, string text, bool itemValue, DropDownList list)
        {
            ListItem listItem = new ListItem(text, itemValue.ToString());

            if (propertyValue == itemValue)
                listItem.Selected = true;

            list.Items.Add(listItem);
        }
    }
}