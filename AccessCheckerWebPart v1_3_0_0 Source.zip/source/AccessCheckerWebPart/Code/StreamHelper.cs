/* 
 *  Created By: Tom Shirley
 *  Project URL: http://www.codeplex.com/accesschecker
 *  License: GNU GPL v2
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using System.Web;
using System.Web.UI;
using System.Runtime;
using System.Diagnostics;

namespace TomShirley.WebParts.AccessChecker
{
    /// <summary>
    /// These functions were created by Michael Freidgeim. Please see http://geekswithblogs.net/mnf/archive/2006/05/26/79669.aspx
    /// Link active as of 2008-01-26.
    /// </summary>
    class StreamHelper
    {
        public static bool EnsureWebResourceValid(string ResName, Assembly Asm, bool ThrowException)
        {
            bool bRet = StreamHelper.EnsureManifestResourceExist(ResName, Asm, ThrowException);
            if (bRet == true)
            { //find the attribute
                bRet = false;
                // Iterate through the attributes for the assembly.
                foreach (Attribute attr in Attribute.GetCustomAttributes(Asm))
                {
                    //Check for WebResource attributes.
                    if (attr.GetType() == typeof(WebResourceAttribute))
                    {
                        WebResourceAttribute wra = (WebResourceAttribute)attr;
                        Debug.WriteLine("Resource in the assembly: " + wra.WebResource.ToString() +
                          " with ContentType = " + wra.ContentType.ToString() +
                          " and PerformsSubstitution = " + wra.PerformSubstitution.ToString());

                        if (wra.WebResource == ResName)
                        {
                            bRet = true;
                            break;
                        }
                    }
                }//foreach
            } //ManifestResourceExist
            if (bRet == false)
            {
                string sMsg = "Embedded resource " + ResName + " in assembly " + Asm.FullName + " doesn't have WebResourceAttribute ";
                if (ThrowException == true)
                {
                    throw new ApplicationException(sMsg);
                }
                else
                {
                    Debug.Assert(false, sMsg);
                }
            }
            return bRet;
        }

        //'if ThrowException=true, then Throw exception if resource not found
        public static bool EnsureManifestResourceExist(string ResName, Assembly Asm, bool ThrowException)
        {   //NOTE: If resource is located in subfolder of C# project, path of subfolder should be specified (it is included as part of namespace)
            //' Resources are named using a fully qualified name ((including namespace).
            bool bRet = true;
            ManifestResourceInfo info = Asm.GetManifestResourceInfo(ResName);

            if (info == null)
            {
                bRet = false;
                string sMsg = "Couldn't find embedded resource " + ResName + " in assembly " + Asm.FullName;

                if (ThrowException)
                {
                    throw new ApplicationException(sMsg);
                }
                else
                {
                    Debug.Assert(false, sMsg);
                }
            }
            return bRet;
        }
    }
}
