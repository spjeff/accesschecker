/* 
 *  Created By: Tom Shirley
 *  Project URL: http://www.codeplex.com/accesschecker
 *  License: GNU GPL v2
 */
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Resources;
using System.Web.UI.WebControls;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebPartPages;
using Microsoft.SharePoint.Utilities;
using arb.Generic.SharedLibrary.exceptionHandling;
using System.Diagnostics;

namespace TomShirley.WebParts.AccessChecker
{
    public partial class AccessCheckerWebPart : WebPart
    {
        #region Properties
        /// <summary>
        /// Stack maintaining the current web's Guid. This property is used when expanding webs as the app pool.
        /// </summary>
        private Stack<Guid> _webGuid = new Stack<Guid>();
        /// <summary>
        /// Current subweb ID, used to open a subweb as the app pool account.
        /// </summary>
        private Guid _subWebGuid = Guid.Empty;
        /// <summary>
        /// Stack maintaining the current sub web's Guid. This property is used when expanding webs as the app pool.
        /// </summary>
        private Stack<int> _subWebIndex = new Stack<int>();
        /// <summary>
        /// Index of a SPList in the current SPWeb's Lists collection, used to obtain a reference to
        /// a list as the app pool account.
        /// </summary>
        private Stack<int> _listIndex = new Stack<int>();
        /// <summary>
        /// Current SPSite's ID, used to obtain a reference to the site as the app pool account.
        /// </summary>
        private Guid _siteGuid = Guid.Empty;
        /// <summary>
        /// Stores a node that represents a list. This property used when the current user does not
        /// have permissions to the current list being processed. See RunWithElevatedPrivileges().
        /// </summary>
        private TreeNode _listTreeNode = null;
        /// <summary>
        /// Stores a node that represents a web. This property used when the current user does not
        /// have permissions to the current web being processed. See RunWithElevatedPrivileges().
        /// </summary>
        private TreeNode _webTreeNode = null;
        private bool _expandSubWebOnly = false;
        private bool isRunningAsAdmin = false;
        private const int MAX_NODE_DEPTH = 30;
        #endregion

        #region Expand object functions
        /// <summary>
        /// Create a TreeNode which conktains a tree hierarchy depicting permissions for a user or
        /// permission inheritance of objects.
        /// </summary>
        /// <param name="currentWeb">The current web.</param>
        /// <param name="currentDepth">The current depth.</param>
        /// <param name="maxDepth">The max depth.</param>
        /// <param name="isRootNode">Is the web the root web.</param>
        /// <returns>AccessTreeNode containing the current Web's subwebs and lists down to a specified depth.</returns>
        private TreeNode ExpandWeb(SPWeb currentWeb, int currentDepth, int maxDepth, bool isRootWeb)
        {
            SPWeb currentSubWeb = null;
            TreeNode currentNode = null, childNodes = null;

            try 
            {
                _webGuid.Push(currentWeb.ID);
                if (currentWeb != null) 
                {
                    try 
                    {
                        currentNode = new TreeNode(currentWeb.ServerRelativeUrl, "", "/_layouts/images/AccessChecker/LINK.GIF", GetEditPermissionsURL(currentWeb, currentWeb.Url), "_blank");
                        currentNode.Value = "SPWeb|" + currentWeb.ID.ToString() + "|" + GetPermissionString(currentWeb);
                        
                        ExpandLists(currentNode, currentWeb); // Add Lists to current web's treeNode
                        // Add the current web's subweb nodes if:
                        // 1. The user wants to display the Sub Webs, set in the WP property DisplaySubWebs
                        // 2. The current node depth is less than the max depth.
                        if (this.DisplaySubWebs && currentDepth < maxDepth)
                        {
                            // Add each subweb node to the current nodes children.  
                            for (int i = 0; i < currentWeb.Webs.Count; i++)
                            {
                                try
                                {
                                    _subWebIndex.Push(i);
                                    // NOTE: currentWeb.Webs[i] can succeed without throwing a security exception, whilst OpenWeb() will throw an exception. Therefore, to obtain the subweb object, use OpenWeb().
                                    currentSubWeb = _CurrentSite.OpenWeb(currentWeb.Webs[i].ID);
                                    childNodes = ExpandWeb(currentSubWeb, currentDepth + 1, maxDepth, false);

                                    if (childNodes != null)
                                        currentNode.ChildNodes.Add(childNodes);
                                }
                                catch (System.UnauthorizedAccessException e)
                                {
                                    TreeNode tempTreeNode = RunExpandWebAsAdmin(true);                                    
                                    if (tempTreeNode != null)
                                        currentNode.ChildNodes.Add(tempTreeNode);
                                }
                                finally
                                {
                                    _subWebIndex.Pop();
                                }
                            }
                        }


                        if (isRootWeb) // Root Node should never be hidden
                            return currentNode;                        
                        else
                        {
                            if (HideNode(currentWeb, currentNode))
                                return null;
                            else
                                return currentNode;
                        }
                    }
                    catch (System.UnauthorizedAccessException e)
                    {
                        return RunExpandWebAsAdmin(false); // currentWeb.Webs failed, so expand the web as admin
                    }
                }
                return null;
            }
            finally
            {
                if (currentWeb != null)
                    currentWeb.Dispose();

                _webGuid.Pop();
            }
        }

        /// <summary>
        /// Expands the lists of an SPWeb object.
        /// </summary>
        /// <param name="currentNode">The current node.</param>
        /// <param name="currentWeb">The current web.</param>
        private void ExpandLists(TreeNode currentNode, SPWeb currentWeb)
        {
            if (isRunningAsAdmin)
                GetListTreeNodes(currentNode, currentWeb);
            else
            {
                try
                {
                    _listTreeNode = currentNode;
                    _webGuid.Push(currentWeb.ID);
                    isRunningAsAdmin = true;
                    SPSecurity.CodeToRunElevated elevatedGetListTreeNodesAsAdmin = new SPSecurity.CodeToRunElevated(GetListTreeNodesAsAdmin);
                    SPSecurity.RunWithElevatedPrivileges(elevatedGetListTreeNodesAsAdmin);
                }
                finally
                {
                    isRunningAsAdmin = false;
                    _webGuid.Pop();
                }
            }
        }

        /// <summary>
        /// Gets the list tree nodes of an SPWeb.
        /// </summary>
        /// <param name="currentNode">The current node that the new list nodes are to be added to.</param>
        /// <param name="currentWeb">The current web.</param>
        private void GetListTreeNodes(TreeNode currentNode, SPWeb currentWeb)
        {
            int i;
            SPList currentList = null;

            if (currentNode != null && currentWeb != null)
            {
                SortedList<string, List<TreeNode>> sl = new SortedList<string, List<TreeNode>>();

                for (i = 0; i < currentWeb.Lists.Count; i++)
                {
                    try
                    {
                        _listIndex.Push(i);
                        currentList = currentWeb.Lists[i];

                        if (currentList.Hidden != true)
                        {
                            TreeNode tnList = new TreeNode(string.Format("{0} ({1})", currentList.Title,
                                currentList.ItemCount),"", currentList.ImageUrl, GetEditPermissionsURL(currentList, currentWeb.Url), "_blank");
                            tnList.Value = "SPList|" + currentList.ID.ToString() + "|" + GetPermissionString(currentList);

                            if (!HideNode(currentList, tnList))
                                AddTreeNodeToSortedList(tnList, sl, tnList.Text);                            
                        }
                    }
                    catch (System.UnauthorizedAccessException e)
                    {
                        SPSecurity.CodeToRunElevated elevatedGetListTreeNodeAsAdmin = new SPSecurity.CodeToRunElevated(GetListTreeNodeAsAdmin);
                        SPSecurity.RunWithElevatedPrivileges(elevatedGetListTreeNodeAsAdmin);
                        if (_listTreeNode != null)
                            AddTreeNodeToSortedList(_listTreeNode, sl, _listTreeNode.Text);    
                    }
                    finally
                    {
                        _listIndex.Pop();
                    }
                }

                foreach (string key in sl.Keys)
                {
                    foreach (TreeNode currentTreeNode in sl[key])
                    {
                        currentNode.ChildNodes.Add(currentTreeNode);
                    }
                }
            }
        }

        private void AddTreeNodeToSortedList(TreeNode treeNode, SortedList<string, List<TreeNode>> sortedList, string key)
        {
            if (sortedList.ContainsKey(key) && sortedList[key] != null)
                sortedList[key].Add(treeNode);
            else
            {
                if (!key.Equals(""))
                {
                    List<TreeNode> treeNodeList = new List<TreeNode>();
                    treeNodeList.Add(treeNode);
                    sortedList.Add(key, treeNodeList);
                }
            }
        }

        #endregion

        #region Expand object as App Pool account functions

        /// <summary>
        /// Execute the ExpandWebAsAdmin() function as the app pool account.
        /// </summary>
        /// <param name="expandSubWebOnly">if set to <c>true</c> [expand sub web only].</param>
        /// <returns>TreeNode object containing the web and list nodes</returns>
        private TreeNode RunExpandWebAsAdmin(bool expandSubWebOnly)
        {
            _expandSubWebOnly = expandSubWebOnly;
            SPSecurity.CodeToRunElevated elevatedExpandWebAsAdmin = new SPSecurity.CodeToRunElevated(ExpandWebAsAdmin);
            SPSecurity.RunWithElevatedPrivileges(elevatedExpandWebAsAdmin);

            return _webTreeNode;
        }

        /// <summary>
        /// Expands the current Web whilst running in the context of the app pool.
        /// </summary>
        private void ExpandWebAsAdmin()
        {
            SPSite site = null;
            SPWeb currentWeb = null;

            if (_webGuid.Count == 0 || _siteGuid == Guid.Empty || _subWebIndex.Count == 0)
                throw new ApplicationException("Could not Expand Web as Admin. Empty web/site guid");

            try
            {
                site = new SPSite(_siteGuid);
                currentWeb = site.OpenWeb(_webGuid.Peek());

                if (_expandSubWebOnly == true)
                    _webTreeNode = ExpandWeb(currentWeb.Webs[_subWebIndex.Peek()], 0, MAX_NODE_DEPTH, false);
                else
                    _webTreeNode = ExpandWeb(currentWeb, 0, MAX_NODE_DEPTH, false);
            }
            catch (Exception e)
            {
                _webTreeNode = null;
                throw;
            }
            finally
            {
                if (site != null)
                    site.Dispose();

                if (currentWeb != null)
                    currentWeb.Dispose();
            }
        }

        /// <summary>
        /// Gets the list tree nodes as admin.
        /// </summary>
        private void GetListTreeNodesAsAdmin()
        {
            SPSite site = null;
            SPWeb currentWeb = null;

            if (_webGuid.Count == 0 || _siteGuid == Guid.Empty)
                throw new ApplicationException("Could not obtain List TreeNode as Admin. Empty web/site guid");

            try
            {
                site = new SPSite(_siteGuid);
                currentWeb = site.OpenWeb(_webGuid.Peek());

                if (_listTreeNode != null)
                    GetListTreeNodes(_listTreeNode, currentWeb);
            }
            catch (Exception e)
            {
                _listTreeNode = null;
                throw;
            }
            finally
            {
                if (site != null)
                    site.Dispose();

                if (currentWeb != null)
                    currentWeb.Dispose();
            }
        }

        /// <summary>
        /// Gets a list tree node as admin.
        /// </summary>
        private void GetListTreeNodeAsAdmin()
        {
            SPSite site = null;
            SPWeb currentWeb = null;
            SPList currentList = null;

            if (_webGuid.Count == 0 || _siteGuid == Guid.Empty || _listIndex.Count == 0)
                throw new ApplicationException(Common.ResourceManager.GetString("Error_Obtaining_List_Tree_Node_As_Admin", _Cult));

            try
            {
                site = new SPSite(_siteGuid);
                currentWeb = site.OpenWeb(_webGuid.Peek());
                currentList = currentWeb.Lists[_listIndex.Peek()];


                _listTreeNode = new TreeNode(string.Format("{0} ({1})", currentList.Title,
                                             currentList.ItemCount), "", currentList.ImageUrl,
                                             GetEditPermissionsURL(currentList, currentWeb.Url), "_blank");
                _listTreeNode.Value = "SPList|" + currentList.ID.ToString() + "|" + GetPermissionString(currentList);
                _listTreeNode.PopulateOnDemand = false;

                if (HideNode(currentList, _listTreeNode))
                    _listTreeNode = null;

            }
            catch (Exception e)
            {
                _listTreeNode = null;
                throw;
            }
            finally
            {

                if (site != null)
                    site.Dispose();

                if (currentWeb != null)
                    currentWeb.Dispose();
            }
        }


        #endregion

        #region Node filtering 
        /// <summary>
        /// Returns a value indicating whether the current TreeNode should be hidden from the user.
        /// </summary>
        /// <param name="secureableObject">The secureable object.</param>
        /// <param name="node">The node in question.</param>
        /// <returns>True if TreeNode should be hidden, false otherwise.</returns>
        private bool HideNode(ISecurableObject secureableObject, TreeNode node)
        {
            bool hideNode = false;
            string selectedFilterValue;

            if (this._TreeNodeFilterRadioList.SelectedValue == string.Empty)
            {
                selectedFilterValue = this.TreeNodeFilter;
            }
            else
                selectedFilterValue = this._TreeNodeFilterRadioList.SelectedValue;

            // If the user wants to hide any nodes that have matching permissions, than:
            // 1. If the ShowUserOrWebPermissions is set to 'Web', than the permission inheritance is what 
            //    the user wants to view. So any nodes that inherit their permissions should be hidden.
            // 2. Otherwise, the ReportObect is set to 'User', which means that the node should
            //    be hidden if:
            //    2.1 The user stored in _PrincipalInfo has permission to the securable object.
            //        This has already been evaluated, and is stored in the nodes Value property.
            //    2.2 The node has no children. The n-ary tree is traversed depth-first, and the logic 
            //        in the calling function ExpandWeb() is such that if a node is to be hidden, it
            //        is not added to the parent node. Therefore if a node has children we must show the
            //        current node.
            if (selectedFilterValue == enumTreeNodeFilterState.HideMatchingPermissionNodes.ToString())
            {
                if (this.ShowUserOrWebPermissions.Equals(enumShowUserOrWebPermissions.Web.ToString()))
                {
                    if (node.ChildNodes != null && node.ChildNodes.Count == 0 && !secureableObject.HasUniqueRoleAssignments)
                        hideNode = true;
                }
                else // Permsissions are generated on a User object
                {
                    if (node.ChildNodes != null && node.ChildNodes.Count == 0 && node.Value.Contains(Common.MATCHING_PERMISSIONS))
                    {
                        hideNode = true;
                    }
                }
            }
            // inverse previous code documentation for description of the below block of code.
            else if (selectedFilterValue == enumTreeNodeFilterState.HideDifferentPermissionNodes.ToString())
            {
                if (this.ShowUserOrWebPermissions.Equals(enumShowUserOrWebPermissions.Web.ToString()))
                {
                    if (node.ChildNodes != null && node.ChildNodes.Count == 0 && secureableObject.HasUniqueRoleAssignments)
                        hideNode = true;
                }
                else // Permsissions are generated on a User object
                {
                    if (node.ChildNodes != null && node.ChildNodes.Count == 0 && node.Value.Contains(Common.DIFFERENT_PERMISSIONS))
                    {
                        hideNode = true;
                    }
                }
            }

            return hideNode;
        }
#endregion

        #region Get Node Data functions

        /// <summary>
        /// Gets the permission string. The permission string is used on the client side to colour code 
        /// TreeNodes representing either a match in permissions or a mismatch.
        /// </summary>
        /// <param name="securableObject">The securable object.</param>
        /// <returns>Return MATCHING_PERMISSIONS if permissions match (a match is dependant on the object
        /// that the user wants to view permissions on) or DIFFERENT_PERMISSIONS if there is a mismatch. </returns>
        private string GetPermissionString(ISecurableObject securableObject)
        {
            bool doesUserHavePermissions = false;

            if (this.ShowUserOrWebPermissions.Equals(enumShowUserOrWebPermissions.Web.ToString()))
                return (securableObject.HasUniqueRoleAssignments ? Common.DIFFERENT_PERMISSIONS : Common.MATCHING_PERMISSIONS);
            else if (this.ShowUserOrWebPermissions.Equals(enumShowUserOrWebPermissions.User.ToString()))
            {
                if (securableObject is SPWeb)
                {
                    SPWeb web = (SPWeb)securableObject;
                   
                    doesUserHavePermissions = web.DoesUserHavePermissions(_PrincipalInfo.LoginName, _BasePermissions);
                    return (doesUserHavePermissions ? Common.MATCHING_PERMISSIONS : Common.DIFFERENT_PERMISSIONS);
                }
                else if (securableObject is SPList)
                {
                    SPList list = (SPList)securableObject;
                    SPWeb web = null;

                    try
                    {
                        web = list.ParentWeb;
                        doesUserHavePermissions = Common.DoesUserHaveListPermissions(_PrincipalInfo.LoginName, list, web, _BasePermissions);
                        return (doesUserHavePermissions ? Common.MATCHING_PERMISSIONS : Common.DIFFERENT_PERMISSIONS);
                    }
                    finally
                    {
                        if (web != null)
                            web.Dispose();
                    }
                }
            }

            throw new ApplicationException(string.Format("{0} GetPermissionString:\r\n{1}", Common.ResourceManager.GetString("Error_in", _Cult),
                Common.ResourceManager.GetString("Object_Type_Not_Supported", _Cult)));
        }

        /// <summary>
        /// Gets the edit permissions URL. This URL is a link to the sharepoint page used to manage permissions for
        /// a securable object.
        /// </summary>
        /// <param name="obj">The obj.</param>
        /// <param name="webURL">The web URL.</param>
        /// <returns></returns>
        private string GetEditPermissionsURL(Object obj, string webURL)
        {
            if (webURL.EndsWith("/"))
                webURL = webURL.Substring(0, webURL.Length - 1);

            if (obj is SPList)
            {
                SPList list = (SPList)obj;
                string guid = SPHttpUtility.UrlKeyValueEncode(list.ID.ToString("B").ToUpper());

                if ((list.BaseType == SPBaseType.DocumentLibrary) && (list.BaseTemplate != SPListTemplateType.WebPartCatalog))
                {
                    return webURL + "/_layouts/user.aspx?obj=" + guid + ",doclib&List=" + guid;
                }
                else
                    return webURL + "/_layouts/user.aspx?obj=" + guid + ",list&List=" + guid;
            }
            else if (obj is SPWeb)
            {
                return webURL + "/_layouts/user.aspx";
            }

            throw new ApplicationException(string.Format("{0} GetEditPermissionsURL:\r\n{1}",
                Common.ResourceManager.GetString("Error_in", _Cult),
                Common.ResourceManager.GetString("Object_Not_Supported_Type", _Cult)));
        }
        #endregion
    }
}