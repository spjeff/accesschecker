Program Details
===============

Name: Access Checker Web Part
Version: 1.3.0
Created By: Tom Shirley
Project URL: http://www.codeplex.com/accesschecker
Email: t.j.shirley@gmail.com
License: GNU GPL v2

The Access Checker Web Part is a Windows Sharepoint Services Web Part, 
for use within Windows Sharepoint Services v3 and Microsoft Office Sharepoint
Server 2007, that displays a tree view showing permissions on objects for a 
user scoped to a Site hierarchy. It also has a second mode which will show 
the permission inheritance of objects within a Site hierarchy.
 
For further information please see http://www.codeplex.com/AccessChecker

Dependancies (included with build)
=================================

	>Access Checker Web Part uses the following programs

	Name: WSPBuilder
	Created By: Carsten Keutmann
	Project URL: http://www.codeplex.com/wspbuilder
	Email: carsten@keutmann.dk
	License: GNU GENERAL PUBLIC LICENSE (GPL)
	License infomation: http://www.codeplex.com/wspbuilder/license
	-----------------------------------------------------------------------------
	Name: SharePoint Solution Installer
	Created By: Lars Fastrup
	Project URL: http://www.codeplex.com/sharepointinstaller
	Email: 
	License: Microsoft Permissive License (Ms-PL) v1.1
	License infomation: http://www.codeplex.com/sharepointinstaller/license

Installation
============
Run Setup.exe on a Sharepoint server as the farm admin account.

Usage
=====
1. To Use the Site Settings Feature:
- Open Sharepoint Central Admin and navigate to 
  Application Management->Manage Web Application Features.
- Activate the Access Checker Feature to enable the Site Settings Pages.

2. To Use the Web Part:
- Navigate to the Site Settings page of a Site Collection, and activate the
  Access Checker Web Part feature under Site Collection Features.

Version History
===============
V1.3.0
- Reworked UI.
- Access Checker now uses the People Picker control to select a user, 
  instead of manually typing in their domain login.
-
v1.2.0
- Access Report can be downloaded as an XML file.
- Access Checker is no longer restricted to site admins only. Users with
  EnumeratePermissions mask have authority to use this tool.
- Lists are displayed before subsites in the tree, for easier identification.
- Error message area is now at the top of the page and the font is colored red.
- CreateSSCSite permission is ignored by default when comparing permissions 
  in User mode. This setting can be configured in the Tool Pane.

v1.1.0
- Added filter control to the Web Part allowing filtering of nodes in the tree.
- Items in the tree are now colored green/red.
- When viewing the permission inheritance of a site hierarchy, the coloring of 
  the nodes is no longer in relation to the current site, it is now in relation
  to the nodes parent object.
- Client side javascript has been cleaned up in order to improve the loading 
  time of the color-bar.
- Node coloring is now printable.

v1.0.1
- Access Checker Site Settings pages are now correctly accessible from 
  within the context web.

v1.0.0
- Initial release.

License
=======
See ./License.txt